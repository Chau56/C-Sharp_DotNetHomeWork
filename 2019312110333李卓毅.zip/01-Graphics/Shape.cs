﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01_Graphics
{
    interface Shape
    {
        bool judgeLegal();
    }
}
