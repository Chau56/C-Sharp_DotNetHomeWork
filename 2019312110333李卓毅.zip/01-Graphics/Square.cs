﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01_Graphics
{
    class Square:Rectangle
    {
        public Square(double len) : base(len, len) { }
    }
}
