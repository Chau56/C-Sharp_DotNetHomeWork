﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02_SumOfArea
{
    interface Area
    {
        double getArea();
    }
}
