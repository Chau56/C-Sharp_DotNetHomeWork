﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02_SumOfArea
{
    class Square:Rectangle
    {
        public Square(double len) : base(len, len) { }
    }
}
