﻿using System;

namespace Homework_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Homework_03");
        }
    }
}
